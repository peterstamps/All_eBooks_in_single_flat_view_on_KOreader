local _ = require("gettext")
return {
    name = "AllMyeBooks",
    fullname = _("AllMyeBooks"),
    description = _([[This plugin creates a collection called All eBooks showing all the eBooks on this reader.]]),
}
